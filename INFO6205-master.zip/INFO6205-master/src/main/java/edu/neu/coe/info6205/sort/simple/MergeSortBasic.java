package edu.neu.coe.info6205.sort.simple;

import edu.neu.coe.info6205.sort.Helper;
import edu.neu.coe.info6205.sort.SortWithHelper;
import edu.neu.coe.info6205.util.Config;

import java.util.Arrays;

public class MergeSortBasic<X extends Comparable<X>> extends SortWithHelper<X> {
	
    public static final String DESCRIPTION = "MergeSort";
    boolean insurance;
    boolean noCopy;

    /**
     * Constructor for MergeSort
     * <p>
     * NOTE this is used only by unit tests, using its own instrumented helper.
     *
     * @param helper an explicit instance of Helper to be used.
     */
    public MergeSortBasic(Helper<X> helper) {
        super(helper);
        insertionSort = new InsertionSort<>(helper);
        
    }

    /**
     * Constructor for MergeSort
     *
     * @param N      the number elements we expect to sort.
     * @param config the configuration.
     */
    public MergeSortBasic(int N, Config config) {
        super(DESCRIPTION + ":" + getConfigString(config), N, config);
        insertionSort = new InsertionSort<>(getHelper());
        insurance = config.getBoolean("instrumenting", "insurance");
        noCopy = config.getBoolean("instrumenting", "noCopy");
        System.out.println("MergeSortBasic Insurance: -------------" + insurance);
        System.out.println("MergeSortBasic NoCopy:    -------------" + noCopy);
    }
   
    private static String getConfigString(Config config) {
        StringBuilder stringBuilder = new StringBuilder();
//        System.out.println("--------------"+config.getBoolean("xxx", "insurance"));
        if (config.getBoolean("xxx", "insurance")) stringBuilder.append(" with insurance comparison");
        if (config.getBoolean("xxx", "noCopy")) stringBuilder.append(" with noCopy comparison");
        return stringBuilder.toString();
    }

    @Override
    public X[] sort(X[] xs, boolean makeCopy) {
        getHelper().init(xs.length);
        X[] result = makeCopy ? Arrays.copyOf(xs, xs.length) : xs;
        // TODO don't copy but just allocate according to the xs/aux interchange optimization
        aux = Arrays.copyOf(xs, xs.length);
        sort(result, 0, result.length);
        return result;
    }

    @Override
    public void sort(X[] a, int from, int to) {
    	final Helper<X> helper = getHelper();
        @SuppressWarnings("UnnecessaryLocalVariable") int lo = from;
//        System.out.println("insurance: "+insurance+ "NoCopy: "+noCopy);
        if(insurance == false && noCopy ==false) {
            if (to <= lo + getHelper().cutoff()) {
                insertionSort.sort(a, from, to);
                return;
            }
            
	        int mid = from + (to - from) / 2;
	        sort(a, lo, mid);
	        sort(a, mid, to);
	        System.arraycopy(a, from, aux, from, to - from);
	        getHelper().incrementCopies(to - from);
	        merge(aux, a, lo, mid, to);  	
        }
        
        if(insurance == true && noCopy == false){
        	if (to <= lo) return; 
        	int mid=lo+(to-lo)/2;
        	sort (a, lo, mid);
        	sort (a, mid+1, to);
        	if (!helper.less(a[mid+1], a[mid])) return; 
        	merge(aux, a, lo, mid, to);
        }
        
        if(insurance == false && noCopy == true) {
        	if (to <= lo) return;
        	int mid = from + (to - from) / 2; 
        	sort (aux, lo, mid);
        	sort (aux, mid+1, to); 
        	merge(a, aux, lo, mid, to);
        }

        if(insurance == true && noCopy == true) {
            System.out.println("insurance" + insurance + "noCopy" + noCopy);
        	if (to <= lo) return;
        	int mid = from + (to - from) / 2; 
        	sort (aux, lo, mid);
        	sort (aux, mid+1, to); 
        	if (!helper.less(aux[mid+1], aux[mid])) return; 
        	merge(a, aux, lo, mid, to);
        }
        
    }
    

    private void merge(X[] aux, X[] a, int lo, int mid, int hi) {
        final Helper<X> helper = getHelper();
        int i = lo;
        int j = mid;
        int k = lo;
        if(insurance == false && noCopy == true) {
        	for (; k < hi; k++)
        		if (i >= mid) helper.copy(a, j++, aux, k);
        		else if (j >= hi) helper.copy(a, i++, aux, k);
        		else if (helper.less(a[j], a[i])) {
        			helper.incrementFixes(mid - i);
        			helper.copy(a, j++, aux, k);
        		} else helper.copy(a, i++, aux, k);
        }
        else {
	        for (; k < hi; k++)
	            if (i >= mid) helper.copy(aux, j++, a, k);
	            else if (j >= hi) helper.copy(aux, i++, a, k);
	            else if (helper.less(aux[j], aux[i])) {
	                helper.incrementFixes(mid - i);
	                helper.copy(aux, j++, a, k);
	            } else helper.copy(aux, i++, a, k);
        }
    }



    private X[] aux = null;
    private final InsertionSort<X> insertionSort;
}

